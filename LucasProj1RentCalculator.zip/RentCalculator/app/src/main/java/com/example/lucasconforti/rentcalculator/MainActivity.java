package com.example.lucasconforti.rentcalculator;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import java.text.NumberFormat;

//MainActivity class for the Tip Calculator app
public class MainActivity extends Activity
{
    //currency and percent formatters
    private static final NumberFormat currencyFormat =
            NumberFormat.getCurrencyInstance();
    private static final NumberFormat percentFormat =
            NumberFormat.getInstance();

    private double billAmount = 0.0;//bill amount entered by user
    private double percent = 2.0;//initial tip percent
    private double month = 12.0;
    private TextView amountTextView;//shows formatted bill amount
    private TextView percentTextView;//shows tip percentage
    private TextView tipTextView;//shows calculated tip amount
    private TextView totalTextView;//shows calculated total bill amount
    private TextView percentTextView1;//shows number of months



    //called when activity is first created
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);//call superclasses version
        setContentView(R.layout.activity_main);//inflate the GUI

        //get references to programmatically manipulated textviews
        amountTextView = (TextView) findViewById(R.id.amountTextView);
        percentTextView = (TextView) findViewById(R.id.percentTextView);
        percentTextView1 = (TextView) findViewById(R.id.percentTextView1);
        tipTextView = (TextView) findViewById(R.id.tipTextView);
        totalTextView = (TextView) findViewById(R.id.totalTextView);
        tipTextView.setText(currencyFormat.format(0));//set text to 0
        totalTextView.setText(currencyFormat.format(0));//set text to 0


        //set amountEditText's TextWatcher
        EditText amountEditText =
                (EditText) findViewById(R.id.amountEditText);
        amountEditText.addTextChangedListener(amountEditTextWatcher);

        //set percentSeekerbar's OnSeekerChangeListener
        SeekBar percentSeekBar =
                (SeekBar) findViewById(R.id.percentSeekBar);
        percentSeekBar.setOnSeekBarChangeListener(seekBarListener);

        SeekBar percentSeekBar1 =
                (SeekBar) findViewById(R.id.percentSeekBar1);
        percentSeekBar1.setOnSeekBarChangeListener(seekBarListener);
    }

    //calculate and display tip and total amounts
    private void calculate()
    {
        //format percent and display in percentTextView
        percentTextView.setText(percentFormat.format(percent));

        //format percent and display in percentTextView
        percentTextView1.setText(percentFormat.format(month));

        //calculate the tip total
        double tip = billAmount / percent;
        double total = tip / month;

        //display tip and total formatted as currency
        tipTextView.setText(currencyFormat.format(tip));
        totalTextView.setText(currencyFormat.format(total));
    }

    //listener object for the SeekBar's progress change events
    private final SeekBar.OnSeekBarChangeListener seekBarListener =
            new SeekBar.OnSeekBarChangeListener() {
                //update percent, then call calculate
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                    if (seekBar.getId() == R.id.percentSeekBar) {
                        percent = progress; // set percent based on progress
                        calculate(); //calculate and display tip + total
                    }
	                else if (seekBar.getId() == R.id.percentSeekBar1) {
                        month = progress;
                        calculate();
                    }

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                    }

            };


    //listener object for the EditText's text-changed events
    private final TextWatcher amountEditTextWatcher = new TextWatcher() {
        //called when the user modifies the bill amount
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {


            try { // get bill amount and display currency formatted value
                billAmount = Double.parseDouble(s.toString()) / 100.0;
                amountTextView.setText(currencyFormat.format(billAmount));
            } catch (NumberFormatException e) {//if s is empty or non-numeric
                amountTextView.setText("");
                billAmount = 0.0;
            }

            calculate(); // update the tip and total TextViews
        }

        @Override
        public void afterTextChanged(Editable s) {
        }

        @Override
        public void beforeTextChanged(
                CharSequence s, int start, int count, int after) {
        }
    };
}